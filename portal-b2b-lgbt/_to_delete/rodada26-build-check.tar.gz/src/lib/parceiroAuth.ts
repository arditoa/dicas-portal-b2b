// Rodada 23 — extraído de /api/aprovar-local pra ser compartilhado com
// /login também (precisa calcular o MESMO e-mail sintético dos dois
// lados: na criação da conta e na hora de entrar).
//
// Por que e-mail sintético em vez de telefone de verdade no Supabase Auth:
// o parceiro digita o WhatsApp e é assim que ele pensa no próprio login,
// mas o provedor "Phone" do Supabase Auth está desativado neste projeto
// (dá "Phone logins are disabled" ao tentar entrar) — ativá-lo pelo
// painel normalmente exige configurar um provedor de SMS (Twilio etc.),
// que é exatamente o custo/complexidade que a Andrea queria evitar ao
// pedir login por WhatsApp em vez de e-mail. Como o provedor de e-mail
// já está ativo e funcionando (usado pelo cadastro manual), a conta do
// parceiro é criada com um e-mail fixo e determinístico calculado a
// partir do próprio WhatsApp (nunca enviado a lugar nenhum, só usado
// internamente pelo Supabase Auth) — o parceiro nunca vê nem digita esse
// e-mail, só o WhatsApp e a senha.

export function normalizarTelefoneBR(whatsapp: string): string {
  const digitos = whatsapp.replace(/\D/g, '');
  return digitos.startsWith('55') ? digitos : `55${digitos}`;
}

export function emailSinteticoParceiro(telefoneNormalizado: string): string {
  return `parceiro.${telefoneNormalizado}@login.vezpabar.app`;
}
