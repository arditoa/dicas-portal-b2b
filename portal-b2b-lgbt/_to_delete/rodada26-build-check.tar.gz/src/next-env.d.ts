/// <reference types="next" />
/// <reference types="next/image-types/global" />

// Declaração para permitir importação de arquivos CSS no TypeScript
declare module "*.css" {
  const content: { [className: string]: string };
  export default content;
}

// NOTE: This file should not be edited
// see https://nextjs.org/docs/app/building-your-application/configuring/typescript for more information.