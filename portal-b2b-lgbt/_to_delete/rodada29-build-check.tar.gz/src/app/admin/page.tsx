'use client';
import { Check, Loader2, MessageCircle, ShieldAlert, X } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { normalizarTelefoneBR } from '../../lib/parceiroAuth';

const URL_PORTAL = 'https://dicas-portal-b2b-dun.vercel.app'; // ajuste aqui quando o domínio definitivo (ex.: portal.vezpabar.com) estiver configurado

// Painel admin mínimo — reaproveita is_admin()/RLS que já existe em todas as
// tabelas (nenhuma migration nova precisou ser feita pra segurança daqui;
// o filtro de acesso abaixo é só de UX, a segurança real já está no banco).
// Cobre as 4 filas de aprovação/ação manual que a investigação encontrou
// sem nenhuma interface: cadastros de local pendentes, pedidos de vínculo
// de conta, leads institucionais, e — a mais importante pra sustentar o
// negócio — parceiros que pediram um plano pago e estão esperando a Andrea
// cobrar (Pix/WhatsApp) e confirmar.

type LocalPendente = {
  id: string;
  nome: string;
  categoria: string;
  cidade: string;
  bairro: string | null;
  cnpj: string | null;
  contato_nome: string | null;
  contato_telefone: string | null;
  contato_email: string | null;
  created_at: string;
};

// Rodada 25 — a festa/evento cadastrado em /cadastro/evento nasce
// `status='pendente'` (mesmo trigger enforce_evento_seguro_insert de
// sempre) mas NUNCA teve fila nenhuma aqui pra aprovar — o /admin só
// tinha filas pra `locais`. A Andrea reportou que uma festa cadastrada
// não aparecia pra aprovação; essa é a causa: a fila simplesmente não
// existia, não é um bug de RLS/trigger (is_admin() já cobre SELECT e
// UPDATE de eventos pendentes, ver pode_gerenciar_evento() na 008).
//
// eventos.descricao carrega o contato/local digitados no cadastro
// (não existe coluna own própria pra isso — ver cadastro/evento/page.tsx,
// "Descrição carrega os dados de contato/local"), por isso é mostrada
// inteira aqui em vez de só um resumo.
type EventoPendente = {
  id: string;
  titulo: string;
  tipo: string;
  descricao: string | null;
  data_inicio: string;
  data_fim: string | null;
  contato_nome: string | null;
  contato_whatsapp: string | null;
  created_at: string;
};

// Rodada 26 — compatibilidade com eventos cadastrados ANTES da migration
// 015: nesses, o contato só existe como texto solto dentro da descrição
// ("Contato: nome — whatsapp", formato exato que cadastro/evento/page.tsx
// sempre gerou). Eventos novos já chegam com contato_nome/contato_whatsapp
// de verdade — isso aqui é só pra não perder o aviso automático nos que já
// estavam pendentes antes da coluna existir.
function extrairContatoDescricao(descricao: string): { nome: string | null; whatsapp: string | null } | null {
  const m = descricao.match(/Contato:\s*([^\n—]+?)\s*—\s*([^\n]+)/);
  if (!m) return null;
  return { nome: m[1].trim() || null, whatsapp: m[2].trim() || null };
}

const PLANO_PRECO: Record<string, string> = {
  starter: 'R$59/mês',
  intermediario: 'R$249/mês',
  premium: 'R$599/mês',
  fundador: 'R$3.500/mês',
};

type InteresseNoPlano = {
  id: string;
  nome: string;
  plano_comercial: string;
  plano_comercial_status: string;
  contato_nome: string | null;
  contato_telefone: string | null;
  contato_email: string | null;
  plano_comercial_atualizado_em: string;
};

type AprovadoSemConta = {
  id: string;
  nome: string;
  contato_nome: string | null;
  contato_telefone: string | null;
  contato_email: string | null;
  owner_id: string | null;
};

// Rodada 29 — pedido direto da Andrea: sem parceiro pagante ainda, como
// deixar "Em Alta"/"Destaque da semana" atraentes? `locais.plano_destaque`
// já existe e já é respeitado pela Home (ordenação + badge "Destaque"/
// "VIP" em (tabs)/index.tsx), mas até agora só dava pra mudar rodando SQL
// na mão — não existia UI nenhuma pra isso. Isso aqui é o seletor manual
// que faltava, pra usar como selo editorial/"Fundador" antes de cobrar de
// verdade. Sem relação com `plano_comercial` (o plano PAGO) — os dois
// aparecem juntos aqui só pra dar contexto, nunca são a mesma coisa.
type LocalDestaque = {
  id: string;
  nome: string;
  categoria: string;
  cidade: string;
  bairro: string | null;
  plano_destaque: 'basico' | 'destaque' | 'vip';
  plano_comercial: string;
  plano_comercial_status: string;
};

type VinculoPendente = {
  id: string;
  local_id: string;
  user_id: string;
  documento_informado: string;
  criado_em: string;
  locais: { nome: string; contato_telefone: string | null; contato_email: string | null } | null;
};

type LeadInstitucional = {
  id: string;
  origem: string;
  nome_organizacao: string;
  nome_contato: string | null;
  email: string | null;
  whatsapp: string | null;
  mensagem: string | null;
  status: string;
  created_at: string;
};

export default function AdminPage() {
  const router = useRouter();
  const [carregando, setCarregando] = useState(true);
  const [autorizado, setAutorizado] = useState(false);

  const [locaisPendentes, setLocaisPendentes] = useState<LocalPendente[]>([]);
  const [eventosPendentes, setEventosPendentes] = useState<EventoPendente[]>([]);
  const [aprovadosSemConta, setAprovadosSemConta] = useState<AprovadoSemConta[]>([]);
  const [locaisDestaque, setLocaisDestaque] = useState<LocalDestaque[]>([]);
  const [vinculosPendentes, setVinculosPendentes] = useState<VinculoPendente[]>([]);
  const [leads, setLeads] = useState<LeadInstitucional[]>([]);
  const [interessesPlano, setInteressesPlano] = useState<InteresseNoPlano[]>([]);
  const [processando, setProcessando] = useState<string | null>(null);
  const [erro, setErro] = useState('');
  // Rodada 22 (correção): window.open() depois de um await é bloqueado
  // silenciosamente por pop-up blocker em vários navegadores — a Andrea
  // confirmou que a aprovação funcionava mas o WhatsApp nunca abria. Em
  // vez de depender de abrir sozinho, mostra um cartão fixo na tela com
  // o link (ela clica) e o telefone/senha em texto (pra copiar também).
  const [contaCriada, setContaCriada] = useState<{ nomeLocal: string; telefone: string; senha: string; link: string } | null>(null);
  // Rodada 26 — mesmo espírito do card de contaCriada acima, mas pra
  // eventos: aprovar evento não cria login (evento não tem dono/conta),
  // só avisa o organizador que já pode ver o evento no app.
  const [eventoAprovado, setEventoAprovado] = useState<{ titulo: string; telefone: string; link: string } | null>(null);

  const carregarFilas = useCallback(async () => {
    const [
      { data: locaisData },
      { data: eventosData },
      { data: aprovadosSemContaData },
      { data: vinculosData },
      { data: leadsData },
      { data: interessesData },
      { data: locaisDestaqueData },
    ] = await Promise.all([
        supabase
          .from('locais')
          .select('id, nome, categoria, cidade, bairro, cnpj, contato_nome, contato_telefone, contato_email, created_at')
          .eq('status', 'pendente')
          .order('created_at', { ascending: true }),
        supabase
          .from('eventos')
          .select('id, titulo, tipo, descricao, data_inicio, data_fim, contato_nome, contato_whatsapp, created_at')
          .eq('status', 'pendente')
          .order('created_at', { ascending: true }),
        supabase
          .from('locais')
          .select('id, nome, contato_nome, contato_telefone, contato_email, owner_id')
          .eq('status', 'aprovado')
          .order('created_at', { ascending: true }),
        supabase
          .from('solicitacoes_vinculo_local')
          .select('id, local_id, user_id, documento_informado, criado_em, locais(nome, contato_telefone, contato_email)')
          .eq('status', 'pendente')
          .order('criado_em', { ascending: true }),
        supabase
          .from('leads_institucionais')
          .select('id, origem, nome_organizacao, nome_contato, email, whatsapp, mensagem, status, created_at')
          .eq('status', 'novo')
          .order('created_at', { ascending: true }),
        supabase
          .from('locais')
          .select('id, nome, plano_comercial, plano_comercial_status, contato_nome, contato_telefone, contato_email, plano_comercial_atualizado_em')
          .in('plano_comercial_status', ['interesse', 'aguardando_pagamento'])
          .order('plano_comercial_atualizado_em', { ascending: true }),
        supabase
          .from('locais')
          .select('id, nome, categoria, cidade, bairro, plano_destaque, plano_comercial, plano_comercial_status')
          .eq('status', 'aprovado')
          .order('nome', { ascending: true }),
      ]);

    setLocaisPendentes((locaisData as LocalPendente[]) || []);
    setEventosPendentes((eventosData as EventoPendente[]) || []);
    setAprovadosSemConta((aprovadosSemContaData as AprovadoSemConta[]) || []);
    setVinculosPendentes((vinculosData as unknown as VinculoPendente[]) || []);
    setLeads((leadsData as LeadInstitucional[]) || []);
    setInteressesPlano((interessesData as InteresseNoPlano[]) || []);
    setLocaisDestaque((locaisDestaqueData as LocalDestaque[]) || []);
  }, []);

  useEffect(() => {
    (async () => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData?.user) {
        router.push('/login');
        return;
      }
      const { data: perfil } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', userData.user.id)
        .maybeSingle();

      if (perfil?.role !== 'admin') {
        setCarregando(false);
        setAutorizado(false);
        return;
      }

      setAutorizado(true);
      await carregarFilas();
      setCarregando(false);
    })();
  }, [router, carregarFilas]);

  // Rodada 22: aprovar já cria a conta de login do parceiro (por WhatsApp,
  // sem e-mail) e vincula o local, tudo numa chamada só, via
  // /api/aprovar-local (roda com a service_role key, nunca a chave anon do
  // navegador — precisa disso pra poder criar contas de autenticação). Ver
  // 012_aprovacao_gera_login_automatico.sql.
  const aprovarLocal = async (id: string) => {
    setProcessando(id);
    setErro('');
    try {
      const { data: sessao } = await supabase.auth.getSession();
      const token = sessao?.session?.access_token;
      const resp = await fetch('/api/aprovar-local', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ local_id: id }),
      });
      const resultado = await resp.json();
      if (!resp.ok) throw new Error(resultado.error || 'Erro ao aprovar.');

      if (resultado.senha) {
        const mensagem = `Boas notícias! Seu cadastro do "${resultado.nomeLocal}" foi aprovado no Dicas LGBT+ 🏳️‍🌈\n\nJá criamos seu acesso ao Portal de Parceiros (fotos, cupons, lista VIP, plano):\n\nLink: ${URL_PORTAL}/login\nLogin (seu WhatsApp): ${resultado.telefone}\nSenha ${resultado.contaNova ? '' : 'nova '}temporária: ${resultado.senha}\n\nDepois de entrar, você pode trocar a senha em "Minha Página". Qualquer dúvida me chama por aqui!`;
        setContaCriada({
          nomeLocal: resultado.nomeLocal,
          telefone: resultado.telefone,
          senha: resultado.senha,
          link: `https://wa.me/${resultado.telefone}?text=${encodeURIComponent(mensagem)}`,
        });
      }
    } catch (e: any) {
      setErro(e.message || 'Erro ao aprovar.');
    }
    await carregarFilas();
    setProcessando(null);
  };

  const rejeitarLocal = async (id: string) => {
    setProcessando(id);
    setErro('');
    const { error } = await supabase.from('locais').update({ status: 'rejeitado' }).eq('id', id);
    if (error) setErro(error.message);
    await carregarFilas();
    setProcessando(null);
  };

  // Eventos não passam por /api/aprovar-local (isso é só pra locais, que
  // ganham login automático — ver Rodada 22/23). Aprovar/rejeitar evento é
  // uma troca simples de status, coberta pela RLS/trigger que já existe
  // desde a Rodada 9 (is_admin() via pode_gerenciar_evento).
  const aprovarEvento = async (ev: EventoPendente) => {
    setProcessando(ev.id);
    setErro('');
    const { error } = await supabase.from('eventos').update({ status: 'aprovado' }).eq('id', ev.id);
    if (error) {
      setErro(error.message);
    } else {
      // Prioriza as colunas de verdade (015); só cai pro texto da
      // descrição se o evento foi cadastrado ANTES dessa migration.
      const extraido = !ev.contato_whatsapp && ev.descricao ? extrairContatoDescricao(ev.descricao) : null;
      const nomeContato = ev.contato_nome || extraido?.nome || null;
      const whatsappBruto = ev.contato_whatsapp || extraido?.whatsapp || null;
      if (whatsappBruto) {
        const telefone = normalizarTelefoneBR(whatsappBruto);
        const mensagem = `Boas notícias${nomeContato ? `, ${nomeContato}` : ''}! Seu evento "${ev.titulo}" foi aprovado no Dicas LGBT+ 🏳️‍🌈 e já está aparecendo no app. Qualquer dúvida me chama por aqui!`;
        setEventoAprovado({
          titulo: ev.titulo,
          telefone,
          link: `https://wa.me/${telefone}?text=${encodeURIComponent(mensagem)}`,
        });
      }
    }
    await carregarFilas();
    setProcessando(null);
  };

  const rejeitarEvento = async (id: string) => {
    setProcessando(id);
    setErro('');
    const { error } = await supabase.from('eventos').update({ status: 'rejeitado' }).eq('id', id);
    if (error) setErro(error.message);
    await carregarFilas();
    setProcessando(null);
  };

  const resolverVinculo = async (id: string, status: 'aprovado' | 'rejeitado') => {
    setProcessando(id);
    setErro('');
    const { error } = await supabase.from('solicitacoes_vinculo_local').update({ status }).eq('id', id);
    if (error) setErro(error.message);
    await carregarFilas();
    setProcessando(null);
  };

  const marcarLeadEmContato = async (id: string) => {
    setProcessando(id);
    setErro('');
    const { error } = await supabase.from('leads_institucionais').update({ status: 'em_contato' }).eq('id', id);
    if (error) setErro(error.message);
    await carregarFilas();
    setProcessando(null);
  };

  // Atualizar plano_comercial_status é a única ação de admin que precisa
  // do banco confirmar de verdade que quem está chamando é admin (o
  // trigger protect_plano_comercial_status, na 005, reverte a mudança se
  // não for) — mas como esta tela já é admin-only, o botão só aparece pra
  // quem tem is_admin() = true de qualquer forma.
  const marcarAguardandoPagamento = async (id: string) => {
    setProcessando(id);
    setErro('');
    const { error } = await supabase.from('locais').update({ plano_comercial_status: 'aguardando_pagamento' }).eq('id', id);
    if (error) setErro(error.message);
    await carregarFilas();
    setProcessando(null);
  };

  const confirmarPagamento = async (id: string) => {
    setProcessando(id);
    setErro('');
    const { error } = await supabase.from('locais').update({ plano_comercial_status: 'ativo' }).eq('id', id);
    if (error) setErro(error.message);
    await carregarFilas();
    setProcessando(null);
  };

  // Rodada 29 — seletor manual de plano_destaque (básico/destaque/vip). É
  // a mesma coluna que a Home já usa pra ordenar "Em Alta"/"Dicas Trip" e
  // mostrar o badge "Destaque"/"VIP" — só que até aqui só dava pra mudar
  // rodando SQL direto no Supabase. Atualização local otimista (não
  // espera o recarregamento de toda fila) pra o select responder na hora.
  const atualizarDestaque = async (id: string, plano: 'basico' | 'destaque' | 'vip') => {
    setProcessando(id);
    setErro('');
    setLocaisDestaque((atual) => atual.map((l) => (l.id === id ? { ...l, plano_destaque: plano } : l)));
    const { error } = await supabase.from('locais').update({ plano_destaque: plano }).eq('id', id);
    if (error) {
      setErro(error.message);
      await carregarFilas();
    }
    setProcessando(null);
  };

  if (carregando) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin text-[#E1306C]" size={28} />
      </div>
    );
  }

  if (!autorizado) {
    return (
      <div className="min-h-screen bg-[#0B0B0E] flex flex-col items-center justify-center p-6 text-center text-white">
        <ShieldAlert className="text-[#E1306C] mb-4" size={32} />
        <h1 className="text-xl font-black mb-2">Acesso restrito</h1>
        <p className="text-[#A0A0B2] text-sm">Essa área é só para administradores.</p>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-5xl mx-auto text-white">
      <h1 className="text-2xl font-black mb-1">Painel de moderação</h1>
      <p className="text-[#A0A0B2] text-xs mb-8">Aprovações manuais — cadastros, vínculos de conta e leads institucionais.</p>

      {contaCriada && (
        <div className="bg-[#4CAF7D]/10 border border-[#4CAF7D]/30 text-[#4CAF7D] p-4 rounded-xl text-xs mb-6">
          <p className="font-bold mb-2">
            ✅ "{contaCriada.nomeLocal}" aprovado e conta criada — o navegador pode ter bloqueado a
            abertura automática do WhatsApp, então aqui está tudo pra enviar manualmente:
          </p>
          <p className="text-[#D0D0E0] mb-2">
            Telefone: <b>{contaCriada.telefone}</b> · Senha temporária: <b>{contaCriada.senha}</b>
          </p>
          <div className="flex items-center gap-3">
            <a
              href={contaCriada.link}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#25D366] text-black font-bold px-3 py-1.5 rounded-lg inline-block"
            >
              Abrir WhatsApp
            </a>
            <button onClick={() => setContaCriada(null)} className="text-[#A0A0B2] hover:text-white">
              Fechar
            </button>
          </div>
        </div>
      )}

      {eventoAprovado && (
        <div className="bg-[#4CAF7D]/10 border border-[#4CAF7D]/30 text-[#4CAF7D] p-4 rounded-xl text-xs mb-6">
          <p className="font-bold mb-2">
            ✅ "{eventoAprovado.titulo}" aprovado — clique pra avisar o organizador por WhatsApp:
          </p>
          <p className="text-[#D0D0E0] mb-2">
            Telefone: <b>{eventoAprovado.telefone}</b>
          </p>
          <div className="flex items-center gap-3">
            <a
              href={eventoAprovado.link}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#25D366] text-black font-bold px-3 py-1.5 rounded-lg inline-block"
            >
              Abrir WhatsApp
            </a>
            <button onClick={() => setEventoAprovado(null)} className="text-[#A0A0B2] hover:text-white">
              Fechar
            </button>
          </div>
        </div>
      )}

      {erro && <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-xl text-xs mb-6">{erro}</div>}

      <section className="mb-10">
        <h2 className="text-base font-bold mb-3 text-[#E1306C]">
          💰 Parceiros interessados em plano pago ({interessesPlano.length})
        </h2>
        <p className="text-xs text-[#626274] mb-3">
          Esta é a fila que sustenta o negócio — ninguém vira assinante sem alguém aqui cobrar por
          Pix/WhatsApp e confirmar.
        </p>
        <div className="space-y-3">
          {interessesPlano.length === 0 && <p className="text-xs text-[#626274]">Nenhum interesse pendente agora.</p>}
          {interessesPlano.map((it) => (
            <div key={it.id} className="bg-[#161520] border border-[#E1306C]/30 rounded-xl p-4 flex justify-between items-start gap-4">
              <div>
                <h3 className="font-bold text-sm">{it.nome}</h3>
                <p className="text-xs text-[#E1306C] font-bold capitalize">
                  {it.plano_comercial} — {PLANO_PRECO[it.plano_comercial] || ''}
                  {it.plano_comercial_status === 'aguardando_pagamento' ? ' (já em contato)' : ' (novo pedido)'}
                </p>
                <p className="text-xs text-[#626274] mt-1">
                  Contato: {it.contato_nome || '—'} · {it.contato_telefone || '—'} · {it.contato_email || '—'}
                </p>
              </div>
              <div className="flex gap-2 shrink-0">
                {it.plano_comercial_status === 'interesse' && (
                  <button
                    onClick={() => marcarAguardandoPagamento(it.id)}
                    disabled={processando === it.id}
                    className="bg-[#232230] text-white text-xs font-bold px-3 py-2 rounded-lg hover:bg-[#2D2B3D]"
                  >
                    Já entrei em contato
                  </button>
                )}
                <button
                  onClick={() => confirmarPagamento(it.id)}
                  disabled={processando === it.id}
                  className="bg-[#4CAF7D]/10 text-[#4CAF7D] border border-[#4CAF7D]/30 text-xs font-bold px-3 py-2 rounded-lg hover:bg-[#4CAF7D]/20"
                >
                  Pagamento confirmado — ativar
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-base font-bold mb-3">Locais pendentes de aprovação ({locaisPendentes.length})</h2>
        <div className="space-y-3">
          {locaisPendentes.length === 0 && <p className="text-xs text-[#626274]">Nenhum pendente.</p>}
          {locaisPendentes.map((l) => (
            <div key={l.id} className="bg-[#161520] border border-[#232230] rounded-xl p-4 flex justify-between items-start gap-4">
              <div>
                <h3 className="font-bold text-sm">{l.nome}</h3>
                <p className="text-xs text-[#A0A0B2] capitalize">
                  {l.categoria} · {l.bairro ? `${l.bairro}, ` : ''}{l.cidade} · CNPJ {l.cnpj || '—'}
                </p>
                <p className="text-xs text-[#626274] mt-1">
                  Contato: {l.contato_nome || '—'} · {l.contato_telefone || '—'} · {l.contato_email || '—'}
                </p>
              </div>
              <div className="flex gap-2 shrink-0">
                <button
                  onClick={() => aprovarLocal(l.id)}
                  disabled={processando === l.id}
                  className="bg-[#4CAF7D]/10 text-[#4CAF7D] border border-[#4CAF7D]/30 p-2 rounded-lg hover:bg-[#4CAF7D]/20"
                  title="Aprovar (já cria o login do parceiro e manda por WhatsApp)"
                >
                  <Check size={16} />
                </button>
                <button
                  onClick={() => rejeitarLocal(l.id)}
                  disabled={processando === l.id}
                  className="bg-red-500/10 text-red-400 border border-red-500/30 p-2 rounded-lg hover:bg-red-500/20"
                  title="Rejeitar"
                >
                  <X size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-base font-bold mb-3">Eventos/festas pendentes de aprovação ({eventosPendentes.length})</h2>
        <div className="space-y-3">
          {eventosPendentes.length === 0 && <p className="text-xs text-[#626274]">Nenhum pendente.</p>}
          {eventosPendentes.map((ev) => (
            <div key={ev.id} className="bg-[#161520] border border-[#232230] rounded-xl p-4 flex justify-between items-start gap-4">
              <div>
                <h3 className="font-bold text-sm">
                  {ev.titulo} <span className="text-[#626274] font-normal capitalize">— {ev.tipo}</span>
                </h3>
                <p className="text-xs text-[#A0A0B2] mt-1">
                  {new Date(ev.data_inicio).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}
                  {ev.data_fim ? ` até ${new Date(ev.data_fim).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}` : ''}
                </p>
                {ev.descricao && (
                  <p className="text-xs text-[#626274] mt-1 whitespace-pre-line">{ev.descricao}</p>
                )}
              </div>
              <div className="flex gap-2 shrink-0">
                <button
                  onClick={() => aprovarEvento(ev)}
                  disabled={processando === ev.id}
                  className="bg-[#4CAF7D]/10 text-[#4CAF7D] border border-[#4CAF7D]/30 p-2 rounded-lg hover:bg-[#4CAF7D]/20"
                  title="Aprovar"
                >
                  <Check size={16} />
                </button>
                <button
                  onClick={() => rejeitarEvento(ev.id)}
                  disabled={processando === ev.id}
                  className="bg-red-500/10 text-red-400 border border-red-500/30 p-2 rounded-lg hover:bg-red-500/20"
                  title="Rejeitar"
                >
                  <X size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-base font-bold mb-3">
          Locais aprovados — enviar/reenviar acesso ao portal ({aprovadosSemConta.length})
        </h2>
        <p className="text-xs text-[#626274] mb-3">
          Já estão no app. Use "Enviar acesso" pra criar a conta de login (se ainda não tiver),
          reparar uma conta antiga que ficou sem jeito de entrar, ou só gerar e mandar uma senha
          temporária nova de novo pelo WhatsApp.
        </p>
        <div className="space-y-3">
          {aprovadosSemConta.length === 0 && <p className="text-xs text-[#626274]">Nenhum aprovado ainda.</p>}
          {aprovadosSemConta.map((l) => (
            <div key={l.id} className="bg-[#161520] border border-[#232230] rounded-xl p-4 flex justify-between items-center gap-4">
              <div>
                <h3 className="font-bold text-sm">{l.nome}</h3>
                <p className="text-xs text-[#626274] mt-1">
                  {l.contato_nome || '—'} · {l.contato_telefone || 'sem telefone cadastrado'} · {l.contato_email || '—'}
                  {l.owner_id ? ' · já tem conta' : ' · sem conta ainda'}
                </p>
              </div>
              <button
                onClick={() => aprovarLocal(l.id)}
                disabled={processando === l.id || !l.contato_telefone}
                className="bg-[#25D366]/10 text-[#25D366] border border-[#25D366]/30 text-xs font-bold px-3 py-2 rounded-lg hover:bg-[#25D366]/20 flex items-center gap-1.5 shrink-0 disabled:opacity-40"
                title={!l.contato_telefone ? 'Sem WhatsApp cadastrado' : 'Enviar acesso'}
              >
                <MessageCircle size={14} /> Enviar acesso
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-base font-bold mb-3">⭐ Destaque manual dos locais ({locaisDestaque.length})</h2>
        <p className="text-xs text-[#626274] mb-3">
          Controla a ordenação e o selo "Destaque"/"VIP" que aparecem no app (Em Alta, Dicas Trip).
          Independente do plano pago — dá pra usar como selo editorial/&quot;Fundador&quot; gratuito
          enquanto ainda não há parceiro pagante, sem precisar cobrar nada ainda.
        </p>
        <div className="space-y-2">
          {locaisDestaque.length === 0 && <p className="text-xs text-[#626274]">Nenhum local aprovado ainda.</p>}
          {locaisDestaque.map((l) => (
            <div key={l.id} className="bg-[#161520] border border-[#232230] rounded-xl p-4 flex justify-between items-center gap-4">
              <div>
                <h3 className="font-bold text-sm">{l.nome}</h3>
                <p className="text-xs text-[#626274] mt-1">
                  {l.categoria} · {[l.bairro, l.cidade].filter(Boolean).join(', ') || '—'}
                  {l.plano_comercial_status === 'ativo'
                    ? ` · plano pago: ${l.plano_comercial}`
                    : ' · sem plano pago ainda'}
                </p>
              </div>
              <select
                value={l.plano_destaque}
                onChange={(e) => atualizarDestaque(l.id, e.target.value as 'basico' | 'destaque' | 'vip')}
                disabled={processando === l.id}
                className="bg-[#0B0B0E] border border-[#232230] rounded-lg text-xs font-bold px-3 py-2 shrink-0 disabled:opacity-40"
              >
                <option value="basico">Básico</option>
                <option value="destaque">Destaque</option>
                <option value="vip">VIP</option>
              </select>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-base font-bold mb-3">Pedidos de vínculo de conta ({vinculosPendentes.length})</h2>
        <div className="space-y-3">
          {vinculosPendentes.length === 0 && <p className="text-xs text-[#626274]">Nenhum pendente.</p>}
          {vinculosPendentes.map((v) => (
            <div key={v.id} className="bg-[#161520] border border-[#232230] rounded-xl p-4 flex justify-between items-start gap-4">
              <div>
                <h3 className="font-bold text-sm">{v.locais?.nome || '(local não encontrado)'}</h3>
                <p className="text-xs text-[#A0A0B2]">CNPJ informado: {v.documento_informado}</p>
                <p className="text-xs text-[#626274] mt-1">
                  Confira o telefone/e-mail do cadastro original ({v.locais?.contato_telefone || '—'} /{' '}
                  {v.locais?.contato_email || '—'}) antes de aprovar.
                </p>
              </div>
              <div className="flex gap-2 shrink-0">
                <button
                  onClick={() => resolverVinculo(v.id, 'aprovado')}
                  disabled={processando === v.id}
                  className="bg-[#4CAF7D]/10 text-[#4CAF7D] border border-[#4CAF7D]/30 p-2 rounded-lg hover:bg-[#4CAF7D]/20"
                  title="Aprovar vínculo"
                >
                  <Check size={16} />
                </button>
                <button
                  onClick={() => resolverVinculo(v.id, 'rejeitado')}
                  disabled={processando === v.id}
                  className="bg-red-500/10 text-red-400 border border-red-500/30 p-2 rounded-lg hover:bg-red-500/20"
                  title="Rejeitar"
                >
                  <X size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-base font-bold mb-3">Leads institucionais novos ({leads.length})</h2>
        <div className="space-y-3">
          {leads.length === 0 && <p className="text-xs text-[#626274]">Nenhum novo.</p>}
          {leads.map((lead) => (
            <div key={lead.id} className="bg-[#161520] border border-[#232230] rounded-xl p-4 flex justify-between items-start gap-4">
              <div>
                <h3 className="font-bold text-sm">{lead.nome_organizacao}</h3>
                <p className="text-xs text-[#A0A0B2] capitalize">{lead.origem.replace(/_/g, ' ')}</p>
                <p className="text-xs text-[#626274] mt-1">
                  {lead.nome_contato || '—'} · {lead.whatsapp || '—'} · {lead.email || '—'}
                </p>
                {lead.mensagem && <p className="text-xs text-[#A0A0B2] mt-1">"{lead.mensagem}"</p>}
              </div>
              <button
                onClick={() => marcarLeadEmContato(lead.id)}
                disabled={processando === lead.id}
                className="bg-[#232230] text-white text-xs font-bold px-3 py-2 rounded-lg hover:bg-[#2D2B3D] shrink-0"
              >
                Marcar em contato
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
